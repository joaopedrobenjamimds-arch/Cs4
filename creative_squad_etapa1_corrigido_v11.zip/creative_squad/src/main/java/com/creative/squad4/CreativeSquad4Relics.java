package com.creative.squad4;

import com.mojang.brigadier.CommandDispatcher;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.util.Unit;

public class CreativeSquad4Relics implements ModInitializer {
    public static final String MOD_ID = "creative_squad_4_relics";

    private static final String LAMP = "§dLampião Lendário";
    private static final String BOOTS = "§6Bota Lendária";
    private static final String CLOCK = "§eRelógio Lendário";
    private static final String COMPASS = "§bBússola Lendária";
    private static final String PICKAXE = "§3Picareta Lendária";
    private static final String FEATHER = "§fPena Lendária";
    private static final String HELMET_A = "§dCapacete dos Gêmeos I";
    private static final String HELMET_B = "§5Capacete dos Gêmeos II";

    @Override
    public void onInitialize() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> registerCommands(dispatcher));
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            for (ServerPlayer player : server.getPlayerList().getPlayers()) {
                tickRelics(player);
            }
        });
    }

    private static void registerCommands(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(Commands.literal("cs4")
            .then(Commands.literal("list").executes(ctx -> {
                ctx.getSource().sendSuccess(() -> Component.literal(
                    "Relíquias disponíveis: lampiao, bota, relogio, bussola, picareta, pena, gemeo1, gemeo2"), false);
                return 1;
            }))
            .then(Commands.literal("give")
                .then(Commands.literal("lampiao").executes(ctx -> give(ctx, relic(Items.LANTERN, LAMP))))
                .then(Commands.literal("bota").executes(ctx -> give(ctx, relic(Items.GOLDEN_BOOTS, BOOTS))))
                .then(Commands.literal("relogio").executes(ctx -> give(ctx, relic(Items.CLOCK, CLOCK))))
                .then(Commands.literal("bussola").executes(ctx -> give(ctx, relic(Items.COMPASS, COMPASS))))
                .then(Commands.literal("picareta").executes(ctx -> give(ctx, relic(Items.DIAMOND_PICKAXE, PICKAXE))))
                .then(Commands.literal("pena").executes(ctx -> give(ctx, relic(Items.FEATHER, FEATHER))))
                .then(Commands.literal("gemeo1").executes(ctx -> give(ctx, relic(Items.GOLDEN_HELMET, HELMET_A))))
                .then(Commands.literal("gemeo2").executes(ctx -> give(ctx, relic(Items.GOLDEN_HELMET, HELMET_B))))
                .then(Commands.literal("all").executes(ctx -> {
                    ServerPlayer p;
                    try {
                        p = ctx.getSource().getPlayerOrException();
                    } catch (com.mojang.brigadier.exceptions.CommandSyntaxException e) {
                        ctx.getSource().sendFailure(Component.literal("Este comando precisa ser usado por um jogador."));
                        return 0;
                    }
                    ItemStack[] stacks = {
                        relic(Items.LANTERN, LAMP), relic(Items.GOLDEN_BOOTS, BOOTS),
                        relic(Items.CLOCK, CLOCK), relic(Items.COMPASS, COMPASS),
                        relic(Items.DIAMOND_PICKAXE, PICKAXE), relic(Items.FEATHER, FEATHER),
                        relic(Items.GOLDEN_HELMET, HELMET_A), relic(Items.GOLDEN_HELMET, HELMET_B)
                    };
                    for (ItemStack stack : stacks) p.getInventory().add(stack);
                    ctx.getSource().sendSuccess(() -> Component.literal("Relíquias entregues."), false);
                    return stacks.length;
                }))
            )
        );
    }

    private static int give(com.mojang.brigadier.context.CommandContext<CommandSourceStack> ctx, ItemStack stack) {
        try {
            ServerPlayer player = ctx.getSource().getPlayerOrException();
            player.getInventory().add(stack);
            ctx.getSource().sendSuccess(() -> Component.literal("Relíquia entregue: ").append(stack.getHoverName()), false);
            return 1;
        } catch (com.mojang.brigadier.exceptions.CommandSyntaxException e) {
            ctx.getSource().sendFailure(Component.literal("Este comando precisa ser usado por um jogador."));
            return 0;
        }
    }

    private static ItemStack relic(Item item, String name) {
        ItemStack stack = new ItemStack(item);
        stack.set(DataComponents.CUSTOM_NAME, Component.literal(name.replace("§d", "").replace("§6", "").replace("§e", "").replace("§b", "").replace("§3", "").replace("§f", "").replace("§5", "")));
        if (item.components().has(DataComponents.MAX_DAMAGE)) {
            stack.set(DataComponents.UNBREAKABLE, Unit.INSTANCE);
        }
        return stack;
    }

    private static boolean named(ItemStack stack, String name) {
        return stack.has(DataComponents.CUSTOM_NAME) && stack.getHoverName().getString().equals(name.replaceAll("§.", ""));
    }

    private static void tickRelics(ServerPlayer player) {
        ItemStack feet = player.getItemBySlot(EquipmentSlot.FEET);
        if (named(feet, BOOTS)) {
            player.addEffect(new MobEffectInstance(MobEffects.SPEED, 40, 4, true, false, true));
        }

        boolean holdingFeather = named(player.getMainHandItem(), FEATHER) || named(player.getOffhandItem(), FEATHER);
        if (holdingFeather) {
            player.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, 40, 0, true, false, true));
        } else {
            player.removeEffect(MobEffects.SLOW_FALLING);
        }

        boolean helmetA = named(player.getItemBySlot(EquipmentSlot.HEAD), HELMET_A);
        boolean helmetB = named(player.getItemBySlot(EquipmentSlot.HEAD), HELMET_B);
        if (helmetA || helmetB) {
            player.addEffect(new MobEffectInstance(MobEffects.RESISTANCE, 40, 0, true, false, true));
        }
    }
}
