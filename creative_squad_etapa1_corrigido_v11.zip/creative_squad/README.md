# Creative Squad 4 Relics

Minecraft 26.1.2 + Fabric Loader 0.19.5.

Esta etapa adiciona relíquias vanilla identificadas por nome e comandos `/cs4 give`.

Comandos:
- `/cs4 list`
- `/cs4 give lampiao`
- `/cs4 give bota`
- `/cs4 give relogio`
- `/cs4 give bussola`
- `/cs4 give picareta`
- `/cs4 give pena`
- `/cs4 give gemeo1`
- `/cs4 give gemeo2`
- `/cs4 give all`
